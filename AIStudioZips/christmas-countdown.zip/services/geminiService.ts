import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateChristmasBackground = async (): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image', // Nano Banana
      contents: {
        parts: [
          {
            text: 'A cheerful, bright, and colorful Christmas cartoon scene. A snowy winter village landscape with cute reindeer, a friendly snowman, and Santa Claus waving. Vibrant colors, vector art style, festive atmosphere. Aspect ratio 16:9.',
          },
        ],
      },
      config: {
        // No schema or mime type for image generation on this model
      }
    });

    // Extract image from response parts
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData && part.inlineData.data) {
          const base64Data = part.inlineData.data;
          const mimeType = part.inlineData.mimeType || 'image/png';
          return `data:${mimeType};base64,${base64Data}`;
        }
      }
    }
    
    throw new Error("No image data found in response");
  } catch (error) {
    console.error("Failed to generate image:", error);
    // Fallback image if generation fails
    return "https://picsum.photos/1920/1080?blur=2"; 
  }
};