import React from 'react';

interface AdventWindowProps {
  number: number;
  isNext: boolean;
  isOpen: boolean;
  onClick: (num: number) => void;
}

export const AdventWindow: React.FC<AdventWindowProps> = ({ number, isNext, isOpen, onClick }) => {
  return (
    <button
      onClick={() => onClick(number)}
      disabled={isOpen || !isNext}
      className={`
        relative flex items-center justify-center w-full h-20 sm:h-24 md:h-28 rounded-xl 
        text-2xl sm:text-4xl font-bold transition-all duration-300 transform
        ${isOpen 
          ? 'window-open cursor-default' 
          : isNext 
            ? 'window-closed hover:scale-105 cursor-pointer text-black-600 shadow-lg' 
            : 'window-closed opacity-75 cursor-not-allowed text-black-400'
        }
      `}
      aria-label={`Window number ${number}`}
    >
      <span className="drop-shadow-sm christmas-font font-bold">
        {number}
      </span>
      {isOpen && (
        <span className="absolute inset-0 flex items-center justify-center text-white/20 text-5xl">
          ❄
        </span>
      )}
    </button>
  );
};